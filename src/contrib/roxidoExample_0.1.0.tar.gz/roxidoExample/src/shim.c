// Automatically regenerated. Do not edit.

void R_init_roxidoExample_rust(void *dll); 
void R_init_roxidoExample(void *dll) { R_init_roxidoExample_rust(dll); }
