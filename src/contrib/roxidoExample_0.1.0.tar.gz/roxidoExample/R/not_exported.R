lists <- function(a1) {
  .Call(.lists, a1)
}
