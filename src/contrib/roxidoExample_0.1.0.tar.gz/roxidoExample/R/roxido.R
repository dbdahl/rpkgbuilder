# Automatically regenerated. Do not edit.

# .Call(.automatic_type_declaration, a1, a2)
# .Call(.automatic_type_declare_matrix_and_array, _a1, _a2)
# .Call(.automatic_type_declare_scalars, _a1, _a2, _a3, _a4, _a5)
# .Call(.automatic_type_declare_slices, _a1, _a2, _a3)
# .Call(.automatic_type_declare_vectors, _a1, a2, a3)
# .Call(.convolve2, a, b)
# .Call(.convolve2_byhand, a, b)
# .Call(.create_r_objects_from_rust_types)
# .Call(.dist__myrnorm, n, mean, sd)
# .Call(.lists, a1)
# .Call(.zero, f, guess1, guess2, tol)

#' @keywords internal
#' @usage NULL
#' @useDynLib roxidoExample, .registration = TRUE
"_PACKAGE"

.Kall <- function(...) {
  x <- .Call(...)
  if (inherits(x, "error")) stop(x) else x
}