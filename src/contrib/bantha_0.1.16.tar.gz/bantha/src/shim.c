// Automatically regenerated. Do not edit.

void R_init_bantha_rust(void *dll); 
void R_init_bantha(void *dll) { R_init_bantha_rust(dll); }
