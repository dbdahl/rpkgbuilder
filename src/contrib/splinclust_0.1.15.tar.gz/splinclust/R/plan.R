#' Plan Splinters for the Splintered Clustering Procedure
#'
#' This function provides a randomize splintering plan for the splintered
#' clustering procedure. Note that \sQuote{nSplinters} * \sQuote{splinterSize}
#' must be at least \sQuote{nItems}.
#'
#' @param nItems Total number of items to cluster.
#' @param nSplinters Number of splinters to form.
#' @param splinterSize Number of items in each splinter.
#'
#' @return A list containing \sQuote{nSplinters} lists, each containing a vector
#'   \sQuote{indices} giving the item numbers for a given splinter.
#' @export
#'
#' @examples
#' plan(20,5,8)
#'
plan <- function(nItems, nSplinters, splinterSize) {
  if (nSplinters * splinterSize < nItems) stop("Not all items are covered. Note that nSplinters * splinterSize must be at least nItems.")
  if (nSplinters == 1) {
    if (splinterSize == nItems) {
      return(list(list(indices = seq_len(nItems))))
    } else {
      stop("If nSplinters == 1, splinterSize must be nItems.")
    }
  } else if (nSplinters < 1) {
    stop("nSplinters must be at least 1.")
  } else if (splinterSize >= nItems) {
    stop("splinterSize should be less than nItems, unless nSplinters == 1.")
  }
  counter <- 0
  result <- vector(mode = "list", nSplinters)
  scratch <- sample(nItems)
  index <- 1
  while (counter < nSplinters) {
    counter <- counter + 1
    if (index + splinterSize - 1 > nItems) {
      remainder <- scratch[seq.int(index, nItems)]
      others <- sample(setdiff(seq_len(nItems), remainder))
      scratch <- c(remainder, others)
      index <- 1
    }
    result[[counter]] <- list(indices = scratch[seq.int(index, index + splinterSize - 1)])
    index <- index + splinterSize
  }
  result
}
