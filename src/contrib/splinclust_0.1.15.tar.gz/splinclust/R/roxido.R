# Automatically regenerated. Do not edit.

# .Call(.dpmm_fit, data, n_samples, burnin, thin, mass, sd)
# .Call(.dpmm_fit2, data, n_samples, burnin, thin, mass, sd)
# .Call(.dpmm_fit3, data, n_samples, burnin, thin, mass, sd)
# .Call(.dpmm_generate, n_items, mass, sd)
# .Call(.expected_loss, estimate, splinters, use_vi, a)
# .Call(.neal_data)
# .Call(.new_splinter, n_items_in_all, items, clusterings)
# .Call(.splintered_clustering, splinters, n_items, max_n_clusters, n_runs, use_vi, a, n_cores)

#' @keywords internal
#' @usage NULL
#' @useDynLib splinclust, .registration = TRUE
"_PACKAGE"

.Kall <- function(...) {
  x <- .Call(...)
  if (inherits(x, "error")) stop(x) else x
}