// Automatically regenerated. Do not edit.

void R_init_splinclust_rust(void *dll); 
void R_init_splinclust(void *dll) { R_init_splinclust_rust(dll); }
